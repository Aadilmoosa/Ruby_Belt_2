class SessionsController < ApplicationController
    def new
    end

    def create
        # this method is wrond I think
        user = User.find_by(email: params[:email])
        if user
            if user.try(:authenticate, params[:password])
                session[:user_id] = user_id
                return redirect_to user_path user.id
            end
            flash[:errors] = ["Password is complete garbage"]
        else
            flash[:errors] = ["Email is complete garbage"]
        end
        return redirect_back :sessions_path
    end
    def destroy
    end
end
