class UsersController < ApplicationController
    # no need for an index page that shows any users or information
    def new
        # no need ofor functionality because all we want to do is render a new user page
        # this page that is rendered is a new user form that has method post to users
        # http://localhost:3000/users/new
    end

    def create
        user = User.create(user_params)
        
        if user.valid?
            session[:user_id] = user.id
            return redirect_to user_path user.id
        end

        flash[:errors] = user.errors.full_messages
        
        return redirect_to :back
        
        # when creting a user or other model/ you do not need the @ sign before initialization, only use the @ sign when you need to display information on the page that you want to render/redirect to 
        # should return to the secrets page with all the secrets
        # http://localhost:3000/users/new
    end

    def edit
    end

    private
        # user strong parameters for mass assignment only
        def user_params
            params.require(:user).permit(:first_name, :last_name, :email, :password, :password_confirmation)
        end
    # end of private methods
end
