FactoryBot.define do
  factory :user do
    first_name "Aadil"
    last_name "Moosa"
    email "AADIL@moosa.com"
    password "password"
  end
end
